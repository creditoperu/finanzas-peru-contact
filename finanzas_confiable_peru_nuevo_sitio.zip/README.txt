FINANZAS CONFIABLE PERÚ — sitio estático

Contenido:
- index.html: página ligera con un botón que abre https://t.me/Finanzasconfiableperu

Publicación gratuita con GitHub Pages:
1. Crea un repositorio nuevo en GitHub.
2. Sube index.html a la raíz del repositorio.
3. En Settings > Pages, selecciona Deploy from a branch.
4. Selecciona la rama main y la carpeta /(root), y guarda.
5. Espera a que GitHub Pages publique la dirección.

Nota: esta página no garantiza la aprobación de anuncios. TikTok revisa también el contenido, la actividad y el cumplimiento de sus políticas.
